graphviz.sty
============

LaTeX package to write Graphviz (dot) files inline
